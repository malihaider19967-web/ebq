import { useEffect, useState, useRef } from '@wordpress/element';
import { __ } from '@wordpress/i18n';
import apiFetch from '@wordpress/api-fetch';
import { createPortal } from 'react-dom';
import { ScoreBadge, CheckCard } from './primitives';
import TrackKeywordButton from './TrackKeywordButton';

/**
 * EBQ live score card. Same shape as the offline `ScoreBadge` so the two
 * read as a matched pair at the top of the SEO tab. Clicking the card
 * opens a portal-mounted popover with the per-factor breakdown (rank,
 * CTR, coverage, cannibalization, audit, tracked) — each rendered as a
 * `CheckCard` with the recommendation + optional action emitted by
 * `LiveSeoScoreService`.
 *
 * Debounced 1.2s on (postId, focusKeyword) so we don't burn API calls
 * every keystroke. The popover is mounted on `document.body` (portal) to
 * escape the Gutenberg sidebar's `overflow:hidden`, and is anchored to
 * the badge via viewport math.
 */
export default function LiveSeoScore({ postId, focusKeyword, isConnected }) {
	const [state, setState] = useState({ status: 'idle', data: null, error: null });
	const [open, setOpen] = useState(false);
	const debounceRef = useRef(null);
	const anchorRef = useRef(null);
	const popRef = useRef(null);
	const [anchor, setAnchor] = useState({ top: 0, left: 0, width: 360 });

	useEffect(() => {
		if (!isConnected || !postId) {
			setState({ status: 'idle', data: null, error: null });
			return;
		}
		clearTimeout(debounceRef.current);
		debounceRef.current = setTimeout(() => {
			setState((s) => ({ ...s, status: 'loading' }));
			const path = `/ebq/v1/seo-score/${postId}` + (focusKeyword ? `?focus_keyword=${encodeURIComponent(focusKeyword)}` : '');
			apiFetch({ path }).then((res) => {
				if (res?.ok === false || res?.error) {
					setState({ status: 'error', data: null, error: res?.message || res?.error || 'Fetch failed' });
				} else {
					setState({ status: 'ready', data: res?.live || null, error: null });
				}
			}).catch((err) => {
				setState({ status: 'error', data: null, error: err?.message || 'Network error' });
			});
		}, 1200);
		return () => clearTimeout(debounceRef.current);
	}, [postId, focusKeyword, isConnected]);

	useEffect(() => {
		if (!open) return;
		const reposition = () => {
			const r = anchorRef.current?.getBoundingClientRect();
			if (!r) return;
			const margin = 12;
			const vw = window.innerWidth;
			const vh = window.innerHeight;
			const popW = Math.min(380, vw - margin * 2);
			let left = Math.max(margin, Math.min(r.left, vw - popW - margin));
			let top = r.bottom + 6;
			const popH = popRef.current?.offsetHeight || 320;
			if (top + popH + margin > vh && r.top - popH - 6 > margin) {
				top = r.top - popH - 6;
			}
			setAnchor({ top, left, width: popW });
		};
		reposition();
		const raf = requestAnimationFrame(reposition);
		const onResize = () => reposition();
		const onScroll = () => reposition();
		const onKey = (e) => { if (e.key === 'Escape') setOpen(false); };
		const onClick = (e) => {
			if (popRef.current?.contains(e.target)) return;
			if (anchorRef.current?.contains(e.target)) return;
			setOpen(false);
		};
		window.addEventListener('resize', onResize);
		window.addEventListener('scroll', onScroll, true);
		document.addEventListener('keydown', onKey, true);
		document.addEventListener('mousedown', onClick, true);
		return () => {
			cancelAnimationFrame(raf);
			window.removeEventListener('resize', onResize);
			window.removeEventListener('scroll', onScroll, true);
			document.removeEventListener('keydown', onKey, true);
			document.removeEventListener('mousedown', onClick, true);
		};
	}, [open]);

	const badgeText = __('EBQ', 'ebq-seo');
	const labelText = __('Live SEO score', 'ebq-seo');

	let score = 0;
	let displayScore = '—';
	let caption = __('Loading…', 'ebq-seo');
	let canOpen = false;
	let data = null;

	if (!isConnected) {
		caption = __('Connect this site to EBQ for the live score.', 'ebq-seo');
	} else if (state.status === 'loading' || state.status === 'idle') {
		caption = __('Fetching live signals…', 'ebq-seo');
	} else if (state.status === 'error') {
		caption = state.error || __('Live score unavailable.', 'ebq-seo');
	} else if (state.status === 'ready') {
		data = state.data;
		if (!data || data.available === false) {
			caption = data?.explanation || __('No live data yet — waiting on Search Console impressions.', 'ebq-seo');
		} else {
			score = Number(data.score) || 0;
			displayScore = score;
			caption = data.label || '';
			canOpen = true;
		}
	}

	const setRef = (el) => { anchorRef.current = el; };

	return (
		<>
			<div ref={setRef} style={{ width: '100%' }}>
				<ScoreBadge
					kind="live"
					score={score}
					displayScore={displayScore}
					badge={badgeText}
					label={labelText}
					caption={caption}
					onClick={canOpen ? () => setOpen((v) => !v) : undefined}
					ariaExpanded={open}
				/>
			</div>

			{open && data && data.available !== false ? createPortal(
				<div
					ref={popRef}
					className="ebq-live-score__pop"
					role="dialog"
					aria-label={__('EBQ live score breakdown', 'ebq-seo')}
					style={{ top: anchor.top, left: anchor.left, width: anchor.width }}
				>
					<header className="ebq-live-score__pop-head">
						<strong>{__('Live SEO score breakdown', 'ebq-seo')}</strong>
						<button
							type="button"
							className="ebq-live-score__pop-close"
							onClick={() => setOpen(false)}
							aria-label={__('Close', 'ebq-seo')}
						>×</button>
					</header>
					{data.explanation ? (
						<p className="ebq-live-score__pop-explanation">{data.explanation}</p>
					) : null}
					<div className="ebq-check-list">
						{(data.factors || []).map((f) => {
							const fLevel = f.score >= 65 ? 'good' : f.score >= 45 ? 'warn' : 'bad';
							let actionEl = null;
							if (f.action?.kind === 'track-keyword' && f.action.keyword) {
								actionEl = <TrackKeywordButton keyword={f.action.keyword} />;
							}
							return (
								<CheckCard
									key={f.key}
									kind="live"
									level={fLevel}
									label={f.label}
									score={f.score}
									detail={f.detail}
									recommendation={f.recommendation || null}
									action={actionEl}
								/>
							);
						})}
					</div>
					<footer className="ebq-live-score__pop-foot">
						{__('Live score uses real Google Search Console data and a Lighthouse audit. The local self-check only sees what you wrote.', 'ebq-seo')}
					</footer>
				</div>,
				document.body
			) : null}
		</>
	);
}
